STEP-1  run the DTW_dataset.py by python DTW_dataset.py
	----after this, we have all the distances of the dataset which we are using
STEP-2  run the model.py with two input files that we want to test
	--python model.py file1.txt file2.txt
now we have the similarity score of these two files.
